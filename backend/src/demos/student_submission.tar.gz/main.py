# main.py

# program that multiplies a number by 2 if it is even, or adds 2 if it is odd
def main():
    try:
        user_input = input()
        number = int(user_input)
        if (number % 2 == 0):
            result = number * 6
        else:
            result = number + 2
        print(result)
    except ValueError:
        print("Invalid input. Please enter an integer.")

if __name__ == "__main__":
    main()